def main():
    return 10

# Boilerplat
if __name__ == "__main__":
    import sys
    ret=main()
    sys.exit(ret)

