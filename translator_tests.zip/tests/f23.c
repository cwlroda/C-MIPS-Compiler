int aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa()
{
    return 11;
}

int main()
{
    return aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa();
}

