int _()
{
    return 11;
}

int main()
{
    return _();
}

