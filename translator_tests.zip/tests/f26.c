int f(int x)
{
    return x-1;
}

int main()
{
    return 10+11*f(1+2);
}

