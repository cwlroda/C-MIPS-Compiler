int _0()
{
    return 11;
}

int main()
{
    return _0();
}

