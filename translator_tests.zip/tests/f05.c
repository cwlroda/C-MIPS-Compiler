int main()
{
    int z;
    z=7;
    z=2*z;
    return z;
}

