int main()
{
    if(2-2){
        return 10;
    }
    return 11;
}

