int main()
{
    int x;
    x=3;
    x=x*x+1;
    return x; 
}

