int yyy_;

int xxx()
{
    int yyy;
    yyy=10;
    return 13;
}

int main()
{
    yyy_=11;
    xxx();
    return yyy_;
}

