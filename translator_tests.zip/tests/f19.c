int main()
{
    int _ab;
    _ab=3;
    return _ab;
}

