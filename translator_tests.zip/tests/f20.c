int main()
{
    int a_b000;
    a_b000=11;
    return a_b000;
}

