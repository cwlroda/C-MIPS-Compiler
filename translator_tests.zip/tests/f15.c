int main()
{
    if(1)
        if(0)
            return 9;
        else
            return 10;
    
    return 10;
}

