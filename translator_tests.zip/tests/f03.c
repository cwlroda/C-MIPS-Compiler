int f(int x)
{
    return 13;
}

int main()
{
    return f(11)+7;
}

