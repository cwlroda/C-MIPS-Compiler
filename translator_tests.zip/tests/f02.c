int f()
{
    return 7;
}

int main()
{
    return f();
}

