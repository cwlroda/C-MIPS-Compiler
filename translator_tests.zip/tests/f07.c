int a;

int main()
{
    a=12;
    return a;
}

