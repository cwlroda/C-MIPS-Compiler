int main()
{
    int _;
    _=2;
    return _;
}

