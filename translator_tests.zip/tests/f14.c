int main()
{
    if(1)
        if(2)
            return 12;
        else
            return 14;
    
    return 9;
}

