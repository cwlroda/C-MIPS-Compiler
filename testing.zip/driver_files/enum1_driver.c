
int g();

int main()
{
    int x;
    return !(g()==1);
}
