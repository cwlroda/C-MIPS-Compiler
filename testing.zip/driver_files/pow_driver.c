
float f(float x, int n);

int main()
{
    return !(f(5.0f,3)==125.0f);
}
