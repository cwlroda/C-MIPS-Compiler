
int f(int n);

int main()
{
    return !(f(5)==15);
}
