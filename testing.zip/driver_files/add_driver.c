
float f(float x, float y);

int main()
{
    return !(f(11.0f,1.0f)==12.0f);
}
