
double f(double x, double y);

int main()
{
    return !(f(11.0,2.0)==22.0);
}
