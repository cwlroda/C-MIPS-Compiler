
int g();

int main()
{
    int x;
    return !(g()=='\\');
}
