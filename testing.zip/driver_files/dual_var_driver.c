
int f();

int main()
{
    return !(f()==1234);
}
