
int f(int x, int y);

int main()
{
    return !(f(20,10)==2);
}
