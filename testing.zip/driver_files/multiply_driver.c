
int multiply(int x, int y);

int main()
{
    return !(multiply(-20,30)==-600);
}
