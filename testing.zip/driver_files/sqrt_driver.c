
int bsqrt(int lo, int hi, int v);

int main()
{
    int x;
    return !(bsqrt(1,1000,64)==8);
}
