
int g(int );

int main()
{
    int x;
    return !(g(16)==17);
}
