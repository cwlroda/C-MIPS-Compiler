
int fib(int x);

int main()
{
    int x;
    return !(fib(6)==8);
}
