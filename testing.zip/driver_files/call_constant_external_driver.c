
int f();

int g()
{ return 20; }

int main()
{
    return !(f()==20);
}
