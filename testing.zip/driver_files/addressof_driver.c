
int f();

int main()
{
    int x;
    return !(f()==13);
}
