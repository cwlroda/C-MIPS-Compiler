
float f(float x, float y, float z);

int main()
{
    return !(f(2.0f,3.0f,4.0f)==10.0f);
}
