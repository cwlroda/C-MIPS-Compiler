
int f();

int g(int x)
{
    return x;
}

int main()
{
    return !(f()==10);
}
