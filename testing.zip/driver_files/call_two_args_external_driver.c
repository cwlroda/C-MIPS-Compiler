
int f();

int g(int x, int y)
{
    return x+y;
}

int main()
{
    return !(f()==30);
}
