unsigned f();

int main()
{
    return !(f()==11);
}
