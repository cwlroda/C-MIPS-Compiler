
int f();

int g(int a, int b, int c, int d, int e)
{
    return a+b+c+d+e;
}

int main()
{
    return !(f()==15);
}
