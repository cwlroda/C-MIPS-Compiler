
int f(int x);

int main()
{
    return !( 40 == f(30) );
}
