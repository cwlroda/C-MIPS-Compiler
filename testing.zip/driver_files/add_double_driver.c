
double f(double x, double y);

int main()
{
    return !(f(11.0,1.0)==12.0);
}
