int f();

int main()
{
    return !(f()==13);
}
