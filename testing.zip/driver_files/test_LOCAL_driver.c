int ffff();

int main()
{
    return !( ffff()==10 );
}
