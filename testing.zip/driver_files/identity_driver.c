
int f(int x);

int main()
{
    return !(f(1234)==1234);
}
