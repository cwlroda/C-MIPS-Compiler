
int g(int x);

int main()
{
    int x;
    return !( (g(1)+g(2))==21);
}
