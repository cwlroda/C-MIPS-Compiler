
int f(int x, int y);

int main()
{
    return !(f(10,20)==19937);
}
