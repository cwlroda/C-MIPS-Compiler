int g();

int f()
{
    return g();
}
