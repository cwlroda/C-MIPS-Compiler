int f()
{
    int x;
    x=5678;
    {
        int x;
        x=1234;
    }
    return x;
}
