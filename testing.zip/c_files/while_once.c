int f()
{
    int x;
    x=1;
    while(x){
        x=0;
    }
    return 19937;
}
