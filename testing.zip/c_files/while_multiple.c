int f()
{
    int x;
    x=20;
    while(x > 10){
        x=x-1;
    }
    return x;
}
