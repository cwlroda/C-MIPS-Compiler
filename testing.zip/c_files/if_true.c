int f()
{
    if(1){
        return 11;
    }
    return 10;
}
