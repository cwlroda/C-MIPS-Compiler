enum X{
    vv 
};

int g()
{
    return vv+1;
}
