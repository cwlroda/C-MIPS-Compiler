int f()
{
    if(1){
        return 11;
    }else{
        return 10;
    }
}
