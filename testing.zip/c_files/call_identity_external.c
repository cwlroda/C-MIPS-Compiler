int g(int x);

int f()
{
    return g(10);
}
