void fakeputs(char *x);

void g()
{
    fakeputs("wibble");
}
