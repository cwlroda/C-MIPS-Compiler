int f()
{
    if(0){
        return 11;
    }else{
        return 10;
    }
}
