int f()
{
    int x;
    return sizeof(x);
}
