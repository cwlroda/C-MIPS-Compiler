int f()
{
    if(0){
        return 11;
    }
    return 10;
}
