double f(double x, double y)
{
    return x*y;
}
