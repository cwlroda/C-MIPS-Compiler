int g(int x)
{
    return x;
}

int f()
{
    return g(10);
}
