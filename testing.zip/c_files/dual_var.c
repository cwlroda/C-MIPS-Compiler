int f()
{
    int x;
    int y;
    x=1234;
    y=x;
    return y;
}
