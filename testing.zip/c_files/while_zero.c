int f()
{
    while(0){
        
    }
    return 19937;
}
