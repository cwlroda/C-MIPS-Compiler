int g()
{
    char *x="\\";
    return x[0];
}
