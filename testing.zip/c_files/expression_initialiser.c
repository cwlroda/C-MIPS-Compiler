int f()
{
    int y=10;
    int x=20 + y;
    return x;
}
