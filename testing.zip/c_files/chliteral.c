int g()
{
    return 'h';
}
