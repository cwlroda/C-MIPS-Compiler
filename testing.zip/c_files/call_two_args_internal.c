int g(int x, int y)
{
    return x+y;
}

int f()
{
    return g(10,20);
}
