enum X{
    vv = 13,
    yy = 10
};

int g()
{
    return vv+yy;
}
