int f()
{
    return sizeof(int);
}
