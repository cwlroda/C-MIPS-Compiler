int g()
{
    return 20;
}

int f()
{
    return g();
}
