int f()
{
    int x=12345;
    return x;
}
