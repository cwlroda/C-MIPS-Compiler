int f()
{
    int x[8];
    x[0]=23;
    return x[0];
}
