int f()
{
    return 5678;
}
