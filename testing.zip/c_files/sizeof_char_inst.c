int f()
{
    char x;
    return sizeof(x);
}
