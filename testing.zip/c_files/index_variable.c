int f()
{
    int i;
    int x[8];
    for(i=0; i<8; i++){
        x[i]=i;
    }
    return x[4];
}
