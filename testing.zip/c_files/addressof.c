int f()
{
    int x;
    int *y=&x;
    return 13;
}
