int g()
{
    char *x="hello";
    return x[0];
}
