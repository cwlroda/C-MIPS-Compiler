int g(int a, int b, int c, int d, int e);

int f()
{
    return g(1,2,3,4,5);
}
