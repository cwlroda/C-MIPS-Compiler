int f()
{
    return 10;
}
