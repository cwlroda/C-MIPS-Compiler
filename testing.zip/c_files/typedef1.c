typedef int int_t;

int g()
{
    int_t x;
    x=13;
    return 13;
}
