int f()
{
    int x;
    x=1;
    x=x+x;
    return x;
}
