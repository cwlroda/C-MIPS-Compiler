int g(int x, int y);

int f()
{
    return g(10,20);
}
