struct x{
    int y;
};

int f()
{
    struct x z;
    z.y=17;
    return 13;
}