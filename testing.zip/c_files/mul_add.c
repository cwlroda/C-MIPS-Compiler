float f(float x, float y, float z)
{
    return x*y+z;
}
