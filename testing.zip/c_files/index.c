int f(int *p)
{
    return p[1];
}
