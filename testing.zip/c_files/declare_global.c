int x[8];

int f()
{
    return 11;
}
