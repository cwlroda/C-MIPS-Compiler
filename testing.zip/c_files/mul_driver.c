
float f(float x, float y);

int main()
{
    return !(f(11.0f,2.0f)==22.0f);
}
