int f()
{
    int y;
    int x[8];
    y=13;
    return y;
}
