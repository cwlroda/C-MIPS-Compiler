int f()
{
    int x;
    for(x=0; x<1; x=x+1){
        
    }
    return x+19937;
}
