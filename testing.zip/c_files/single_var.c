int f()
{
    int x;
    x=1234;
    return x;
}
