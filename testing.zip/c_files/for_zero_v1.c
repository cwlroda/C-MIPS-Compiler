int f()
{
    int x;
    for(x=0; x<0; x=x+1){
        return 1;
    }
    return 19937;
}
