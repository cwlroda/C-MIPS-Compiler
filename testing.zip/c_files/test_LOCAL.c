int ffff()
{
    int x;
    x=10;
    return x;
}
