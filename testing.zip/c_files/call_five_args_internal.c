int g(int a, int b, int c, int d, int e)
{
    return a+b+c+d+e;
}

int f()
{
    return g(1,2,3,4,5);
}
