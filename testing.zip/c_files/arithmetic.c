int f(int *p)
{
    p=p+1;
    return *p;
}
