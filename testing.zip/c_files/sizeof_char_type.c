int f()
{
    return sizeof(char);
}
